"""Django admin configuration.

This is a minimal placeholder. Add your admin utilities here when migrating tools.
"""

from django.contrib import admin

# TODO: Add VirtualModelAdmin base class and utilities when migrating existing tools

